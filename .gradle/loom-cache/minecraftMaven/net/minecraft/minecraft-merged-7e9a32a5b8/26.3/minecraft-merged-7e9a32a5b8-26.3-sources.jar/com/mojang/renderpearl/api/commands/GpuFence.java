/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package com.mojang.renderpearl.api.commands;

import com.mojang.renderpearl.util.UncheckedAutoCloseable;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public interface GpuFence
extends UncheckedAutoCloseable {
    public static final long NO_TIMEOUT = -1L;

    @Override
    public void close();

    public boolean awaitCompletion(long var1);
}

