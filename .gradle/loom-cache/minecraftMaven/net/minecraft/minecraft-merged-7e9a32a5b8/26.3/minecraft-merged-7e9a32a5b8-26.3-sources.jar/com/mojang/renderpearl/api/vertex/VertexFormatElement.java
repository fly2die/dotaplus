/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package com.mojang.renderpearl.api.vertex;

import com.mojang.renderpearl.api.GpuFormat;
import java.util.Locale;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public record VertexFormatElement(String name, int offset, GpuFormat format) {
    @Override
    public String toString() {
        return String.format(Locale.ROOT, "%s %s offset:%d", new Object[]{this.name, this.format, this.offset});
    }
}

