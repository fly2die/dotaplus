/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package com.mojang.blaze3d.platform;

import com.mojang.logging.LogUtils;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.util.StringDecomposer;
import org.lwjgl.sdl.SDLClipboard;
import org.lwjgl.sdl.SDLError;
import org.slf4j.Logger;

@Environment(value=EnvType.CLIENT)
public class ClipboardManager {
    private static final Logger LOGGER = LogUtils.getLogger();

    public String getClipboard() {
        String clipboard = SDLClipboard.SDL_GetClipboardText();
        if (clipboard == null) {
            LOGGER.error("Failed to read clipboard: {}", (Object)SDLError.SDL_GetError());
            return "";
        }
        return StringDecomposer.filterBrokenSurrogates(clipboard);
    }

    public void setClipboard(String clipboard) {
        if (!SDLClipboard.SDL_SetClipboardText(clipboard)) {
            LOGGER.error("Failed to set clipboard: {}", (Object)SDLError.SDL_GetError());
        }
    }
}

