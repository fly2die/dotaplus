/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package com.mojang.renderpearl.api.device;

import com.mojang.renderpearl.api.device.BackendCreationException;
import com.mojang.renderpearl.api.device.GpuDebugOptions;
import com.mojang.renderpearl.api.device.GpuDevice;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.jspecify.annotations.Nullable;

@Environment(value=EnvType.CLIENT)
public interface GpuBackend {
    public String getName();

    public void loadLibrary() throws BackendCreationException;

    public void unloadLibrary();

    public long createWindow(@Nullable String var1, int var2, int var3, long var4);

    public GpuDevice createDevice(GpuDebugOptions var1) throws BackendCreationException;
}

