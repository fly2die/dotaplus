/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package com.mojang.renderpearl.util;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.jspecify.annotations.Nullable;

@Environment(value=EnvType.CLIENT)
public interface UncheckedAutoCloseable
extends AutoCloseable {
    @Override
    public void close();

    public static void safeClose(@Nullable UncheckedAutoCloseable closeable) {
        if (closeable == null) {
            return;
        }
        closeable.close();
    }
}

