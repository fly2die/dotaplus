/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package com.mojang.realmsclient.dto;

import com.google.gson.annotations.SerializedName;
import com.mojang.realmsclient.dto.ReflectionBasedSerialization;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.jspecify.annotations.Nullable;

@Environment(value=EnvType.CLIENT)
public record InviteCodeRequestDto(@SerializedName(value="linkId") @Nullable String code, @SerializedName(value="realmId") long realmId, @SerializedName(value="enabled") boolean enabled, @SerializedName(value="expirationDate") @Nullable Long expirationDate) implements ReflectionBasedSerialization
{
    @SerializedName(value="linkId")
    public @Nullable String code() {
        return this.code;
    }

    @SerializedName(value="realmId")
    public long realmId() {
        return this.realmId;
    }

    @SerializedName(value="enabled")
    public boolean enabled() {
        return this.enabled;
    }

    @SerializedName(value="expirationDate")
    public @Nullable Long expirationDate() {
        return this.expirationDate;
    }
}

