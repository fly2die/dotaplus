/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package com.mojang.renderpearl.api.device;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public class SurfaceException
extends Exception {
    public SurfaceException(String message) {
        super(message);
    }

    public SurfaceException(Throwable cause) {
        super(cause);
    }
}

