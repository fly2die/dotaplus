/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package com.mojang.renderpearl.api.commands;

import com.mojang.renderpearl.util.UncheckedAutoCloseable;
import java.util.OptionalLong;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public interface GpuQueryPool
extends UncheckedAutoCloseable {
    public int size();

    public OptionalLong getValue(int var1);

    public OptionalLong[] getValues(int var1, int var2);
}

