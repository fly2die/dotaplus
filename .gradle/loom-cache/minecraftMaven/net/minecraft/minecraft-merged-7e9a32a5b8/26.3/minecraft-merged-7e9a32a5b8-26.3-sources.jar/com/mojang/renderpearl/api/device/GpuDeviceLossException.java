/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package com.mojang.renderpearl.api.device;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public class GpuDeviceLossException
extends RuntimeException {
    public GpuDeviceLossException(String message) {
        super(message);
    }
}

