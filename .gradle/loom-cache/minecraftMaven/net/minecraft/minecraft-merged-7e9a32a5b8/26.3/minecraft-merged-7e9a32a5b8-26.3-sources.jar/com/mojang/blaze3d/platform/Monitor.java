/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package com.mojang.blaze3d.platform;

import com.google.common.collect.ImmutableList;
import com.mojang.blaze3d.platform.VideoMode;
import com.mojang.logging.LogUtils;
import java.util.HexFormat;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Optional;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.jspecify.annotations.Nullable;
import org.lwjgl.PointerBuffer;
import org.lwjgl.sdl.SDLError;
import org.lwjgl.sdl.SDLStdinc;
import org.lwjgl.sdl.SDLVideo;
import org.lwjgl.sdl.SDL_DisplayMode;
import org.lwjgl.sdl.SDL_Rect;
import org.lwjgl.system.MemoryStack;
import org.slf4j.Logger;

@Environment(value=EnvType.CLIENT)
public record Monitor(String name, int id, List<VideoMode> videoModes, VideoMode currentMode, int x, int y, int w, int h) {
    private static final Logger LOGGER = LogUtils.getLogger();
    private static final HexFormat HEX_FORMAT = HexFormat.of().withUpperCase();

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static @Nullable Monitor tryCreate(int id) {
        String name = Monitor.queryMonitorName(id);
        ImmutableList.Builder videoModes = ImmutableList.builder();
        try (MemoryStack stack = MemoryStack.stackPush();){
            VideoMode mode;
            PointerBuffer modes = SDLVideo.SDL_GetFullscreenDisplayModes(id);
            if (modes == null) {
                LOGGER.warn("Failed to query video modes of monitor {}: {}", (Object)name, (Object)SDLError.SDL_GetError());
                Monitor monitor = null;
                return monitor;
            }
            try {
                for (int i = 0; i < modes.limit(); ++i) {
                    mode = new VideoMode(SDL_DisplayMode.create(modes.get(i)));
                    if (mode.getRedBits() < 8 || mode.getGreenBits() < 8 || mode.getBlueBits() < 8) continue;
                    videoModes.add(mode);
                }
            } finally {
                SDLStdinc.SDL_free(modes);
            }
            SDL_Rect bounds = SDL_Rect.malloc(stack);
            if (!SDLVideo.SDL_GetDisplayBounds(id, bounds)) {
                LOGGER.warn("Failed to query monitor bounds of {}: {}", (Object)name, (Object)SDLError.SDL_GetError());
                mode = null;
                return mode;
            }
            SDL_DisplayMode currentMode = SDLVideo.SDL_GetDesktopDisplayMode(id);
            if (currentMode == null) {
                LOGGER.warn("Failed to query current desktop video mode of monitor {}: {}", (Object)name, (Object)SDLError.SDL_GetError());
                Monitor monitor = null;
                return monitor;
            }
            Monitor monitor = new Monitor(name, id, (List<VideoMode>)((Object)videoModes.build()), new VideoMode(currentMode), bounds.x(), bounds.y(), bounds.w(), bounds.h());
            return monitor;
        }
    }

    private static String queryMonitorName(int id) {
        String monitorName = Objects.requireNonNullElse(SDLVideo.SDL_GetDisplayName(id), "unknown");
        return monitorName + "[0x" + HEX_FORMAT.toHexDigits(id) + "]";
    }

    public VideoMode getPreferredVideoMode(Optional<VideoMode> expectedMode) {
        return expectedMode.filter(this.videoModes::contains).orElse(this.currentMode);
    }

    public int indexOfMode(VideoMode expectedMode) {
        return this.videoModes.indexOf(expectedMode);
    }

    public VideoMode mode(int mode) {
        return this.videoModes.get(mode);
    }

    public int modeCount() {
        return this.videoModes.size();
    }

    @Override
    public String toString() {
        return String.format(Locale.ROOT, "%s(%s at (%d,%d))", this.name, this.currentMode, this.x, this.y);
    }
}

