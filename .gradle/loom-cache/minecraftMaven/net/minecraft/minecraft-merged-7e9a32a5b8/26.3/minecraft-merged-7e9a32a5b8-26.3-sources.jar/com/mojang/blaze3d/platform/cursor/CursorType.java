/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package com.mojang.blaze3d.platform.cursor;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.lwjgl.sdl.SDLMouse;

@Environment(value=EnvType.CLIENT)
public class CursorType {
    public static final CursorType DEFAULT = new CursorType("default", 0L);
    private final String name;
    private final long handle;

    private CursorType(String name, long handle) {
        this.name = name;
        this.handle = handle;
    }

    public void select() {
        long cursor = this.handle == 0L ? SDLMouse.SDL_GetDefaultCursor() : this.handle;
        SDLMouse.SDL_SetCursor(cursor);
    }

    public String toString() {
        return this.name;
    }

    public static CursorType createStandardCursor(int shape, String name, CursorType fallback) {
        long handle = SDLMouse.SDL_CreateSystemCursor(shape);
        if (handle == 0L) {
            return fallback;
        }
        return new CursorType(name, handle);
    }
}

