/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package com.mojang.renderpearl.backend.vulkan;

import com.mojang.renderpearl.api.buffers.GpuBuffer;
import com.mojang.renderpearl.api.buffers.GpuBufferSlice;
import com.mojang.renderpearl.backend.common.BaseGpuBuffer;
import com.mojang.renderpearl.backend.vulkan.Destroyable;
import com.mojang.renderpearl.backend.vulkan.VulkanConst;
import com.mojang.renderpearl.backend.vulkan.VulkanDevice;
import com.mojang.renderpearl.backend.vulkan.VulkanUtils;
import java.nio.ByteBuffer;
import java.nio.LongBuffer;
import java.util.Objects;
import java.util.function.Supplier;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.jspecify.annotations.Nullable;
import org.lwjgl.PointerBuffer;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.system.MemoryUtil;
import org.lwjgl.util.vma.Vma;
import org.lwjgl.util.vma.VmaAllocationCreateInfo;
import org.lwjgl.vulkan.VkBufferCreateInfo;

@Environment(value=EnvType.CLIENT)
public abstract class VulkanGpuBuffer
extends BaseGpuBuffer
implements Destroyable {
    private final long vkBuffer;

    public VulkanGpuBuffer(long vkBuffer, @GpuBuffer.Usage int usage, long size) {
        super(usage, size);
        this.vkBuffer = vkBuffer;
    }

    public long vkBuffer() {
        return this.vkBuffer;
    }

    @Environment(value=EnvType.CLIENT)
    public static class Direct
    extends VulkanGpuBuffer {
        private boolean closed;
        protected final VulkanDevice device;
        private final long vmaAllocation;
        private int mappingRefCount;

        public Direct(VulkanDevice device, @Nullable Supplier<String> label, @GpuBuffer.Usage int usage, long size, boolean forceHostVisibleAllocation) {
            long vkBuffer;
            this.device = device;
            try (MemoryStack stack = MemoryStack.stackPush();){
                VkBufferCreateInfo bufferCreateInfo = VkBufferCreateInfo.calloc(stack).sType$Default();
                bufferCreateInfo.size(size);
                bufferCreateInfo.usage(VulkanConst.bufferUsageToVk(usage));
                bufferCreateInfo.sharingMode(0);
                bufferCreateInfo.pQueueFamilyIndices(null);
                VmaAllocationCreateInfo allocCreateInfo = VmaAllocationCreateInfo.calloc(stack);
                allocCreateInfo.usage(8);
                if (forceHostVisibleAllocation) {
                    allocCreateInfo.requiredFlags(allocCreateInfo.requiredFlags() | 2);
                }
                if (VulkanUtils.hasAnyBit(usage, 3)) {
                    allocCreateInfo.requiredFlags(allocCreateInfo.requiredFlags() | 2 | 4);
                    if (VulkanUtils.hasAnyBit(usage, 1)) {
                        allocCreateInfo.preferredFlags(allocCreateInfo.preferredFlags() | 8);
                        allocCreateInfo.flags(allocCreateInfo.flags() | 0x800);
                    } else {
                        allocCreateInfo.flags(allocCreateInfo.flags() | 0x400);
                    }
                }
                if (VulkanUtils.hasAnyBit(usage, 5)) {
                    allocCreateInfo.usage(9);
                }
                LongBuffer bufferPtr = stack.callocLong(1);
                PointerBuffer allocPtr = stack.callocPointer(1);
                int result = Vma.vmaCreateBuffer(device.vma(), bufferCreateInfo, allocCreateInfo, bufferPtr, allocPtr, null);
                VulkanUtils.crashIfFailure(device, result, "Failed to allocate VkBuffer");
                vkBuffer = bufferPtr.get(0);
                this.vmaAllocation = allocPtr.get(0);
                if (label != null) {
                    device.instance().debug().setObjectName(device.vkDevice(), 9, vkBuffer, label);
                }
            }
            super(vkBuffer, usage, size);
            this.closed = false;
            this.mappingRefCount = 0;
        }

        @Override
        public void destroy() {
            Vma.vmaDestroyBuffer(this.device.vma(), this.vkBuffer(), this.vmaAllocation);
        }

        @Override
        public boolean isClosed() {
            return this.closed;
        }

        @Override
        public void close() {
            if (this.closed) {
                return;
            }
            this.closed = true;
            if (this.mappingRefCount != 0) {
                throw new IllegalStateException("Attempt to close a mapped buffer");
            }
            this.device.createCommandEncoder().queueForDestroy(this);
        }

        @Override
        public GpuBufferSlice.MappedView map(long offset, long length, boolean read, boolean write) {
            if (this.isClosed()) {
                throw new IllegalStateException("Buffer already closed");
            }
            if (!read && !write) {
                throw new IllegalArgumentException("At least read or write must be true");
            }
            if (read && (this.usage() & 1) == 0) {
                throw new IllegalStateException("Buffer is not readable");
            }
            if (write && (this.usage() & 2) == 0) {
                throw new IllegalStateException("Buffer is not writable");
            }
            if (offset + length > this.size()) {
                throw new IllegalArgumentException("Cannot map more data than this buffer can hold (attempting to map " + length + " bytes at offset " + offset + " from " + this.size() + " size buffer)");
            }
            if (length > Integer.MAX_VALUE) {
                throw new IllegalArgumentException("Mapping buffer slice larger than 2GB is not supported");
            }
            if (offset < 0L || length < 0L) {
                throw new IllegalArgumentException("Offset or length must be positive integer values");
            }
            ++this.mappingRefCount;
            try (MemoryStack stack = MemoryStack.stackPush();){
                PointerBuffer pointer = stack.callocPointer(1);
                VulkanUtils.crashIfFailure(this.device, Vma.vmaMapMemory(this.device.vma(), this.vmaAllocation, pointer), "Failed to map buffer");
                ByteBuffer byteBuffer = MemoryUtil.memByteBuffer(pointer.get(0) + offset, (int)length);
                GpuBufferSlice.MappedView mappedView = new GpuBufferSlice.MappedView(this.slice(offset, length), byteBuffer, new Runnable(this){
                    private boolean closed;
                    final /* synthetic */ Direct this$0;
                    {
                        Direct direct = this$0;
                        Objects.requireNonNull(direct);
                        this.this$0 = direct;
                        this.closed = false;
                    }

                    @Override
                    public void run() {
                        if (this.closed) {
                            return;
                        }
                        this.closed = true;
                        --this.this$0.mappingRefCount;
                        Vma.vmaUnmapMemory(this.this$0.device.vma(), this.this$0.vmaAllocation);
                    }
                });
                return mappedView;
            }
        }
    }
}

