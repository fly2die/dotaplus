/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package com.mojang.renderpearl.api.pipeline;

import com.mojang.renderpearl.api.pipeline.ShaderType;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.resources.Identifier;
import org.jspecify.annotations.Nullable;
import org.lwjgl.system.MemoryUtil;
import org.lwjgl.util.shaderc.ShadercIncludeResult;

@Environment(value=EnvType.CLIENT)
public interface ShaderSource
extends AutoCloseable {
    public @Nullable String getShader(Identifier var1, ShaderType var2);

    public @Nullable CachedIncludeSource getInclude(Identifier var1);

    @Override
    public void close();

    @Environment(value=EnvType.CLIENT)
    public record CachedIncludeSource(long includeResultPtr) implements AutoCloseable
    {
        public static CachedIncludeSource create(Identifier id, String source) {
            ShadercIncludeResult result = ShadercIncludeResult.calloc();
            result.source_name(MemoryUtil.memUTF8(id.toString(), false));
            result.content(MemoryUtil.memUTF8(source, false));
            return new CachedIncludeSource(result.address());
        }

        public static CachedIncludeSource createError(String message) {
            ShadercIncludeResult result = ShadercIncludeResult.calloc();
            result.source_name(MemoryUtil.memUTF8("", false));
            result.content(MemoryUtil.memUTF8(message, false));
            return new CachedIncludeSource(result.address());
        }

        @Override
        public void close() {
            MemoryUtil.nmemFree(MemoryUtil.memGetAddress(this.includeResultPtr + (long)ShadercIncludeResult.SOURCE_NAME));
            MemoryUtil.nmemFree(MemoryUtil.memGetAddress(this.includeResultPtr + (long)ShadercIncludeResult.CONTENT));
            MemoryUtil.nmemFree(this.includeResultPtr);
        }
    }
}

