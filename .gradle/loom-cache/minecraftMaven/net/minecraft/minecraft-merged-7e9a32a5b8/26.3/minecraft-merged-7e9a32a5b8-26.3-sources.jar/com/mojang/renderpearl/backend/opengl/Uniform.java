/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package com.mojang.renderpearl.backend.opengl;

import com.mojang.renderpearl.api.GpuFormat;
import com.mojang.renderpearl.backend.opengl.GlStateManager;
import com.mojang.renderpearl.util.UncheckedAutoCloseable;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public sealed interface Uniform
extends UncheckedAutoCloseable {
    @Override
    default public void close() {
    }

    @Environment(value=EnvType.CLIENT)
    public record Sampler(int samplerIndex) implements Uniform
    {
    }

    @Environment(value=EnvType.CLIENT)
    public record Utb(int samplerIndex, GpuFormat format, int texture) implements Uniform
    {
        public Utb(int samplerIndex, GpuFormat format) {
            this(samplerIndex, format, GlStateManager._genTexture());
        }

        @Override
        public void close() {
            GlStateManager._deleteTexture(this.texture);
        }
    }

    @Environment(value=EnvType.CLIENT)
    public record Ubo(int blockBinding) implements Uniform
    {
    }
}

