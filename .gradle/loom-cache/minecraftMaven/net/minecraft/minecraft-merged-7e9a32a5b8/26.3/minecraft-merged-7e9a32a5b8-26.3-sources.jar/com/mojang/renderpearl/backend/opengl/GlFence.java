/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package com.mojang.renderpearl.backend.opengl;

import com.mojang.renderpearl.api.commands.GpuFence;
import com.mojang.renderpearl.backend.opengl.GlCommandEncoder;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public class GlFence
implements GpuFence {
    private final GlCommandEncoder encoder;
    private final long submitIndex;
    private boolean closedOrCompleted;

    GlFence(GlCommandEncoder encoder) {
        this.encoder = encoder;
        this.submitIndex = encoder.currentSubmitIndex();
    }

    @Override
    public void close() {
        this.closedOrCompleted = true;
    }

    @Override
    public boolean awaitCompletion(long timeoutNS) {
        if (this.closedOrCompleted) {
            return true;
        }
        this.closedOrCompleted = this.encoder.awaitSubmit(this.submitIndex, timeoutNS);
        return this.closedOrCompleted;
    }
}

