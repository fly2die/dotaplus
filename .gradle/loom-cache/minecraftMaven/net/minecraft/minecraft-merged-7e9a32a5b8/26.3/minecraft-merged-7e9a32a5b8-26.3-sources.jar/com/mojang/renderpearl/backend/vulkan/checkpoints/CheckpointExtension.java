/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package com.mojang.renderpearl.backend.vulkan.checkpoints;

import com.mojang.renderpearl.backend.vulkan.VulkanDevice;
import com.mojang.renderpearl.backend.vulkan.VulkanQueue;
import com.mojang.renderpearl.util.UncheckedAutoCloseable;
import java.util.List;
import java.util.function.Supplier;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.lwjgl.vulkan.VkCommandBuffer;

@Environment(value=EnvType.CLIENT)
public interface CheckpointExtension
extends UncheckedAutoCloseable {
    public CheckpointStorage createStorage(VulkanDevice var1, VulkanQueue var2, int var3);

    public List<QueueCheckpoints> retrieveCheckpoints(boolean var1);

    @Environment(value=EnvType.CLIENT)
    public record StageCheckpoint(long stage, CheckpointType type, String label) {
    }

    @Environment(value=EnvType.CLIENT)
    public record QueueCheckpoints(long queue, List<StageCheckpoint> checkpoints) {
    }

    @Environment(value=EnvType.CLIENT)
    public static enum CheckpointType {
        BEGIN_RENDER_PASS,
        END_RENDER_PASS;

    }

    @Environment(value=EnvType.CLIENT)
    public static interface CheckpointStorage {
        public void rotate();

        public void recordCheckpoint(VkCommandBuffer var1, CheckpointType var2, Supplier<String> var3);
    }
}

