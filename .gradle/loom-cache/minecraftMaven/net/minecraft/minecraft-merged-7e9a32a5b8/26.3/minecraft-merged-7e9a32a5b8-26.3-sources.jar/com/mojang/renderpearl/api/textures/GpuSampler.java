/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package com.mojang.renderpearl.api.textures;

import com.mojang.renderpearl.api.textures.AddressMode;
import com.mojang.renderpearl.api.textures.FilterMode;
import com.mojang.renderpearl.util.UncheckedAutoCloseable;
import java.util.OptionalDouble;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public interface GpuSampler
extends UncheckedAutoCloseable {
    public AddressMode getAddressModeU();

    public AddressMode getAddressModeV();

    public FilterMode getMinFilter();

    public FilterMode getMagFilter();

    public int getMaxAnisotropy();

    public OptionalDouble getMaxLod();

    public boolean isClosed();
}

