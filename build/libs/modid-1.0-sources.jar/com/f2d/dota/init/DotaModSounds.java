/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package com.f2d.dota.init;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.Identifier;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.Registry;

import com.f2d.dota.DotaMod;

public class DotaModSounds {
	public static SoundEvent ITEM_ABYSSAL_BLADE;
	public static SoundEvent ITEM_BASHER;

	public static void load() {
		ITEM_ABYSSAL_BLADE = register("item.abyssal_blade", SoundEvent.createVariableRangeEvent(Identifier.fromNamespaceAndPath("dota", "item.abyssal_blade")));
		ITEM_BASHER = register("item.basher", SoundEvent.createVariableRangeEvent(Identifier.fromNamespaceAndPath("dota", "item.basher")));
	}

	private static SoundEvent register(String registryname, SoundEvent element) {
		return Registry.register(BuiltInRegistries.SOUND_EVENT, Identifier.fromNamespaceAndPath(DotaMod.MODID, registryname), element);
	}
}